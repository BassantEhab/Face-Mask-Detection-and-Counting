
Facemask_detaction - v1 facemask no augmantation
==============================

This dataset was exported via roboflow.ai on June 11, 2021 at 7:47 PM GMT

It includes 635 images.
Mask are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


